/* 患者詳細：バイタル（最新の表示・記録・これまでの一覧） */
let vitals = [];

function setupVitals(){
  const now = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  $('vitalForm').innerHTML = `
    <div class="field-row">
      ${VITAL_FIELDS.map(f => `
        <label class="field"><span>${f.label}（${f.unit}）</span>
          <input type="number" name="${f.key}" step="${f.step}" min="${f.min}" max="${f.max}" inputmode="decimal">
        </label>`).join('')}
    </div>
    <label class="field"><span>測った日時</span><input type="datetime-local" name="measured_at" value="${now}"></label>
    <div class="editor-foot"><span class="muted tiny">わかる項目だけで大丈夫です</span><button type="submit" class="primary">記録する</button></div>`;

  $('vitalToggle').addEventListener('click', () => $('vitalForm').classList.toggle('hidden'));
  $('vitalForm').addEventListener('submit', saveVital);
}

async function loadVitals(){
  try{
    vitals = await listVitals(patientId, 10);
    renderVitals();
  }catch(e){ showError(e, 'バイタルを読み込めませんでした'); }
}

function renderVitals(){
  const v = vitals[0];
  $('vitalTime').textContent = v ? `最新：${fmtDateTime(v.measured_at, true)}（${v.employee_master ? v.employee_master.employee_name : ''}）` : 'まだ記録がありません';
  const cell = (label, value, unit) => `<div><small>${label}</small><b>${value ?? '—'}${value != null ? `<i>${unit}</i>` : ''}</b></div>`;
  $('vitals').innerHTML = [
    cell('体温', v && v.body_temp, '℃'),
    cell('血圧', v && (v.bp_systolic != null ? `${v.bp_systolic}/${v.bp_diastolic ?? '-'}` : null), ''),
    cell('脈拍', v && v.pulse, '回/分'),
    cell('SpO₂', v && v.spo2, '%'),
    cell('呼吸数', v && v.resp_rate, '回/分'),
    cell('記録数', vitals.length, '件')
  ].join('');

  $('vitalTable').innerHTML = vitals.length ? `
    <thead><tr><th>日時</th><th>体温</th><th>血圧</th><th>脈拍</th><th>SpO₂</th><th>呼吸数</th><th>記録した人</th></tr></thead>
    <tbody>${vitals.map(r => `
      <tr>
        <td>${fmtDateTime(r.measured_at, true)}</td>
        <td>${r.body_temp ?? '—'}</td>
        <td>${r.bp_systolic != null ? `${r.bp_systolic}/${r.bp_diastolic ?? '-'}` : '—'}</td>
        <td>${r.pulse ?? '—'}</td>
        <td>${r.spo2 ?? '—'}</td>
        <td>${r.resp_rate ?? '—'}</td>
        <td>${esc(r.employee_master ? r.employee_master.employee_name : '')}</td>
      </tr>`).join('')}</tbody>` : '<tbody><tr><td class="muted">記録はありません</td></tr></tbody>';
}

async function saveVital(e){
  e.preventDefault();
  const form = $('vitalForm');
  const row = { patient_id: patientId, admission_id: detail.current ? detail.current.admission_id : null, employee_id: session.employeeId };
  let filled = 0;
  for(const f of VITAL_FIELDS){
    const input = form.elements[f.key];
    if(input.value === ''){ row[f.key] = null; continue; }
    const num = Number(input.value);
    if(Number.isNaN(num) || num < f.min || num > f.max){
      toast(`${f.label}は ${f.min}〜${f.max} の数字で入力してください`);
      input.focus();
      return;
    }
    row[f.key] = num;
    filled++;
  }
  if(!filled){ toast('どれか1つは入力してください'); return; }
  const at = form.elements.measured_at.value;
  row.measured_at = at ? new Date(at).toISOString() : new Date().toISOString();

  try{
    await addVital(row);
    VITAL_FIELDS.forEach(f => { form.elements[f.key].value = ''; });
    form.classList.add('hidden');
    toast('バイタルを記録しました');
    await loadVitals();
  }catch(err){ showError(err, '記録できませんでした'); }
}
