/* バイタル（vital_sign） */
const VITAL_FIELDS = [
  { key: 'body_temp',    label: '体温',   unit: '℃',   step: '0.1', min: 30, max: 43 },
  { key: 'bp_systolic',  label: '血圧（上）', unit: 'mmHg', step: '1', min: 40, max: 260 },
  { key: 'bp_diastolic', label: '血圧（下）', unit: 'mmHg', step: '1', min: 20, max: 180 },
  { key: 'pulse',        label: '脈拍',   unit: '回/分', step: '1', min: 20, max: 250 },
  { key: 'spo2',         label: 'SpO₂',   unit: '%',    step: '1', min: 50, max: 100 },
  { key: 'resp_rate',    label: '呼吸数', unit: '回/分', step: '1', min: 4,  max: 60 }
];

async function listVitals(patientId, limit = 10){
  return db.select('vital_sign', `select=*,employee_master(employee_name)&patient_id=eq.${patientId}&order=measured_at.desc&limit=${limit}`);
}

async function addVital(row){
  return db.insert('vital_sign', row);
}

/* 1 行のバイタルを短い文章に（例：体温 36.8℃／血圧 128/76／…） */
function vitalText(v){
  if(!v) return '';
  const parts = [];
  if(v.body_temp != null) parts.push(`体温 ${v.body_temp}℃`);
  if(v.bp_systolic != null || v.bp_diastolic != null) parts.push(`血圧 ${v.bp_systolic ?? '-'}/${v.bp_diastolic ?? '-'}`);
  if(v.pulse != null) parts.push(`脈拍 ${v.pulse}`);
  if(v.spo2 != null) parts.push(`SpO₂ ${v.spo2}%`);
  if(v.resp_rate != null) parts.push(`呼吸数 ${v.resp_rate}`);
  return parts.join('／');
}
